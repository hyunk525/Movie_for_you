import pandas as pd
import matplotlib.pyplot as plt
from wordcloud import WordCloud
import collections
from matplotlib import font_manager, rc
import numpy as np
from PIL import Image

font_path = './malgun.ttf'
font_name = font_manager.FontProperties(fname=font_path).get_name()
plt.rc('font', family='NanumBarunGothic')

df = pd.read_csv('./crawling_data/CRO/reviews_2017_2022.csv')
words = df[df['titles'] == '아이들은 즐겁다 (Kids Are Fine)']['review']  #2717
#print(words)
words = words.iloc[0].split()
#print(words)

worddict = collections.Counter(words)
worddict = dict(worddict)
#print(worddict)

wordcloud_img = WordCloud(background_color='white', max_words=2000, font_path=font_path).generate_from_frequencies(worddict)

plt.figure(figsize=(12, 12))
plt.imshow(wordcloud_img, interpolation='bilinear')
plt.axis('off')
plt.show()